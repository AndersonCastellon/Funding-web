export interface Category {
  name: string;
  icon: string;
  url?: string;
}
