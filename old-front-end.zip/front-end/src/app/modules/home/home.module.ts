import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { Routes, RouterModule } from '@angular/router';
import { SlideSectionModule } from '../ui/slide-section/slide-section.module';
import { BlogSectionModule } from '../ui/blog-section/blog-section.module';
import { PrincipalCategoriesSectionModule } from '../ui/principal-categories-section/principal-categories-section.module';

const ROUTES: Routes = [{ path: '', component: HomeComponent }];

@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    BlogSectionModule,
    SlideSectionModule,
    PrincipalCategoriesSectionModule,
    RouterModule.forChild(ROUTES),
  ],
})
export class HomeModule {}
