import { Component, OnInit, Input } from '@angular/core';
import { Category } from 'src/app/models/category.module';

@Component({
  selector: 'app-card-category',
  templateUrl: './card-category.component.html',
  styles: [],
})
export class CardCategoryComponent implements OnInit {
  @Input() category: Category;
  constructor() {}

  ngOnInit(): void {}
}
