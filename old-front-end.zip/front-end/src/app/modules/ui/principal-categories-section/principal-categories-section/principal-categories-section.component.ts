import { Component, OnInit, Input } from '@angular/core';
import { Category } from 'src/app/models/category.module';

@Component({
  selector: 'app-principal-categories-section',
  templateUrl: './principal-categories-section.component.html',
  styles: [],
})
export class PrincipalCategoriesSectionComponent implements OnInit {
  @Input() public categories: Category[];
  constructor() {}

  ngOnInit(): void {
    this.categories = [
      {
        name: 'Ayuda Social',
        icon: 'fas fa-hands-helping',
      },
      {
        name: 'Hogar',
        icon: 'fas fa-home',
      },
      {
        name: 'Tecnología',
        icon: 'fas fa-laptop',
      },
      {
        name: 'Salud',
        icon: 'fas fa-running',
      },
    ];
  }
}
