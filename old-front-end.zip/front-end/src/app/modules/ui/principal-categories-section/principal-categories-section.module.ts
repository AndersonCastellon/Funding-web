import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrincipalCategoriesSectionComponent } from './principal-categories-section/principal-categories-section.component';
import { CardCategoryModule } from '../card-category/card-category.module';

@NgModule({
  declarations: [PrincipalCategoriesSectionComponent],
  imports: [CommonModule, CardCategoryModule],
  exports: [PrincipalCategoriesSectionComponent],
})
export class PrincipalCategoriesSectionModule {}
